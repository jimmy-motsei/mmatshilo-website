export const DEFAULT_APPROACH = process.env.NEXT_PUBLIC_APPROACH ?? 'A'; // 'A' or 'B'
export const SITE = {
  name: 'Dr Mmatshilo Motsei',
  tagline: 'Healing the self. Re-membering the world.',
};
