import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="Retreats & Immersions" sub="Land-based and online gatherings for rites of passage." />) }
