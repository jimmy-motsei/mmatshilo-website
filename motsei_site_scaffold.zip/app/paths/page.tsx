import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="Find your path" sub="Personalized journeys across courses, circles, and rituals." />) }
