import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="An atlas of remembering" sub="Browse themes across land, lineage, dignity, birth." />) }
