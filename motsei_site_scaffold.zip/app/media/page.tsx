import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="In the media" sub="Conversations on healing, birth and leadership." />) }
