import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="From midwife to integrative healer" sub="A journey where science and spirit collaborate." />) }
