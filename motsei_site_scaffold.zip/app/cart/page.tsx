import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="Your selections" sub="Books, courses, retreats." />) }
