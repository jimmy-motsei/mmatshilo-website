import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="Let’s begin with a conversation" sub="Book a discovery call or request a program." />) }
