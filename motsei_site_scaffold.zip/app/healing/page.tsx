import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="Birth a new way of being" sub="Safe, trauma-aware spaces for transformation." />) }
