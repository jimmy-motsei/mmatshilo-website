import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="A gentle guide" sub="Reflection prompts and wayfinding with privacy by design." />) }
