import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="Soft power. Strong teams." sub="Women’s health, cultural competency and She‑Elephant leadership." />) }
