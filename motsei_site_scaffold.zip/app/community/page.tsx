import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="Belonging is medicine" sub="Gather, learn, and lead together." />) }
