import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="Welcome back" sub="Your courses, circles and journey." />) }
