import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="Culture, care, and soft-power leadership" sub="Women’s health, mindfulness, cultural competency." />) }
