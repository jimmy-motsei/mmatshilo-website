import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="A story of remembering" sub="From wound to womb to world." />) }
