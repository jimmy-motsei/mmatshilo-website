import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="Hearing Visions, Seeing Voices" sub="A memoir of activism and spiritual becoming." />) }
