import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="Words that weave the soul" sub="Memoir, critique and guidance for healing and change." />) }
