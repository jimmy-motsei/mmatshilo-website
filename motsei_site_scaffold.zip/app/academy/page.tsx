import Hero from '@/components/Hero'
export default function Page(){ return (<Hero title="Learn, remember, reweave" sub="Courses and cohorts rooted in African wisdom and practice." />) }
